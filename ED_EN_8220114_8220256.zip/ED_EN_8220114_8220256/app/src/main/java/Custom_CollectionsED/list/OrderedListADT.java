package Custom_CollectionsED.list;

import Custom_CollectionsED.list.ListADT;

public interface OrderedListADT<T>  extends ListADT<T> {

    public void add(T element);
}
