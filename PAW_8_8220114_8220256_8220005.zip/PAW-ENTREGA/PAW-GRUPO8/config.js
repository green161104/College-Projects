
module.exports = {
    'SESSION_SECRET': 'foifyvrllcixehfuzmurxrfrocvrnekwvcbpvvvtrlmgebpiqsvpileagkedngos ',
    'JWT_SECRET': 'zrbvanapyiezfliddinzylqrnbezfhqewcriujoxxzmtmgxyydqxbvpyzfnohzszkmtttajtsvadbyqriqoifthifanqwarx',
    'LIVE_URL': 'http://localhost:4200',
    "USER":"burnerandre54@gmail.com", 
    "PASS":"dywr qtjk owbz uyrr "
};
