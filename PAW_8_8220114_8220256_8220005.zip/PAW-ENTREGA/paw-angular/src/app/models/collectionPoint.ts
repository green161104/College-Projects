export class CollectionPoint{
    _id!:string;
    name!: string;
    coordsLatitude!: number;
    coordsLongitude!:number;
    numberOfDonationsProcessed!:number;
}

