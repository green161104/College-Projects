

export class Coupon {
    _id!:string;
    sponsor!: string;
    value!: number;
    cost!: number;
}