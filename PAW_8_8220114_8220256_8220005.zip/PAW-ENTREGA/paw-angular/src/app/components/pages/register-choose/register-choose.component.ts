import { Component } from '@angular/core';

@Component({
  selector: 'app-register-choose',
  templateUrl: './register-choose.component.html',
  styleUrl: './register-choose.component.css'
})
export class RegisterChooseComponent {

}
